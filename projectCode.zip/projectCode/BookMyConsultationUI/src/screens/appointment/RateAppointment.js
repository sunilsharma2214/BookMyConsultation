import React, {useState, useEffect} from "react";
import TextField from '@mui/material/TextField';
import Rating from '@mui/material/Rating';
import Typography from '@mui/material/Typography';
import FormHelperText from '@mui/material/FormHelperText';
import Button from '@mui/material/Button';
import {postRating} from '../../util/fetch';

const RateAppointment = (props) => {
    const [comments, setComments] = useState("");
    const [rating, setRating] = useState(null);
    const [ratingErr, setRatingErr] = useState(false);

    const rateAppointment = async () => {
        if(!rating){
            setRatingErr(true);
            return;
        }
        setRatingErr(false);
        const payload = {
            "appointmentId": props.appointment.appointmentId,
            "doctorId": props.appointment.doctorId,
            "rating": rating.toString(),
            "comments": comments
        };
        const res = await postRating(payload);
        if(res.status === 200){
            props.closeModal();
        }
        
    }

    return (
        <div>
            <TextField
                value={comments}
                label="Comments"
                variant="standard"
                sx={{marginBottom: "20px"}}
                onChange={(e) => {
                    setComments(e.target.value);
                }}
            />
            <div className="mb-20">
                <Typography component="span">Rating: </Typography>
                <Rating
                    name="Rating"
                    value={rating}
                    onChange={(event, newValue) => {
                        setRating(newValue);
                    }}
                />
                {
                        ratingErr &&
                        <FormHelperText sx={{color: "red"}} >Select a rating</FormHelperText>
                }
            </div>
            <Button variant="contained" onClick={rateAppointment}>RATE APPOINTMENT</Button>
        </div>
    );
};

export default RateAppointment;