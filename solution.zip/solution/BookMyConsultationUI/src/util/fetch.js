const baseUrl = "http://localhost:8080";

export const authenticateUser = (data) => {
    const temp = btoa(data.emailId + ":" + data.password);
    return fetch(`${baseUrl}/auth/login`, {
        method: "POST",
        headers: {
            'Authorization': `Basic ${temp}`,
        },
        body: JSON.stringify(data)
    })
    .then(response => response)
    .catch(error => {
        console.error('There was an error!', error);
    });
}

export const logout = () => {
    const accessToken = JSON.parse(localStorage.getItem("user")).accessToken;
    return fetch(`${baseUrl}/auth/logout`, {
        method: "POST",
        headers: {
            'Authorization': `Bearer ${accessToken}`,
        }
    })
    .then(response => {
        localStorage.clear();
        return response;
    })
    .catch(error => {
        console.error('There was an error!', error);
    });
}

export const register = (data) => {
    return fetch(`${baseUrl}/users/register`, {
        method: "POST",
        headers: {
            'Content-Type': "application/json",
        },
        body: JSON.stringify(data)
    })
    .then(response => response)
    .catch(error => {
        console.error('There was an error!', error);
    });
}


export const getDoctors = () => {
    return fetch(`${baseUrl}/doctors`, {
        method: "GET",
        headers: {
            'Authorization': `Bearer`,
        }
    })
    .then(response => response)
    .catch(error => {
        console.error('There was an error!', error);
    });
}

export const getSpeciality = () => {
    return fetch(`${baseUrl}/doctors/speciality`, {
        method: "GET",
        headers: {
            'Authorization': `Bearer`,
        }
    })
    .then(response => response)
    .catch(error => {
        console.error('There was an error!', error);
    });
}

export const getDoctorBySpeciality = (speciality) => {
    return fetch(`${baseUrl}/doctors?speciality=${speciality}`, {
        method: "GET",
        headers: {
            'Authorization': `Bearer`,
        }
    })
    .then(response => response)
    .catch(error => {
        console.error('There was an error!', error);
    });
}

export const getTimeSlotList = (data) => {
    return fetch(`${baseUrl}/doctors/${data.id}/timeSlots/?date=${data.date}`, {
        method: "GET",
        headers: {
            'Authorization': `Bearer`,
        }
    })
    .then(response => response)
    .catch(error => {
        console.error('There was an error!', error);
    });
}

export const bookUserAppointment = (data) => {
    const user = JSON.parse(localStorage.getItem("user"));
    return fetch(`${baseUrl}/appointments`, {
        method: "POST",
        headers: {
            'Authorization': `Bearer ${user.accessToken}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
    .then(response => response)
    .catch(error => {
        console.error('There was an error!', error);
    });
}

export const getAppointments = () => {
    const user = JSON.parse(localStorage.getItem("user"));
    return fetch(`${baseUrl}/users/${user.emailAddress}/appointments`, {
        method: "GET",
        headers: {
            'Authorization': `Bearer ${user.accessToken}`,
        }
    })
    .then(response => response)
    .catch(error => {
        console.error('There was an error!', error);
    });
}

export const postRating = (data) => {
    const user = JSON.parse(localStorage.getItem("user"));
    return fetch(`${baseUrl}/ratings`, {
        method: "POST",
        headers: {
            'Authorization': `Bearer ${user.accessToken}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
    .then(response => response)
    .catch(error => {
        console.error('There was an error!', error);
    });
}