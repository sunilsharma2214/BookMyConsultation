import React from "react";
import Typography from "@material-ui/core/Typography";
import Rating from '@mui/material/Rating';
import './DoctorDetails.css';

const DoctorDetails = (props) => {
    return (
        <Typography component="div">
            <h4 className="doctor-name">Dr: {props.selectedDoctor.firstName} {props.selectedDoctor.lastName}</h4>
            <p className="doctor-total-exp">Total Experience: {props.selectedDoctor.totalYearsOfExp}</p>
            <p className="doctor-speciality">Speciality: {props.selectedDoctor.speciality}</p>
            <p className="doctor-dob">Date of Birth : {props.selectedDoctor.dob}</p>
            <p className="doctor-city">City: {props.selectedDoctor.address?.city}</p>
            <p className="doctor-email">Email: {props.selectedDoctor.emailId}</p>
            <p className="doctor-mobile">Mobile : {props.selectedDoctor.mobile}</p>
            <p className="doctor-rating">Rating : <Rating name={`rating_${props.selectedDoctor.id}`} value={props.selectedDoctor.rating} readOnly /></p>
        </Typography>
    );
};

export default DoctorDetails;