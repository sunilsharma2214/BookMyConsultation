import React, {useEffect, useState} from "react";
import Typography from "@material-ui/core/Typography";
import Button from '@mui/material/Button';
import Paper from '@mui/material/Paper';
import Modal from 'react-modal';
import Card from '@mui/material/Card';
import {getAppointments} from '../../util/fetch';
import RateAppointment from './RateAppointment';

Modal.setAppElement('#root');

const Appointment = () => {
    const [isUserLoggedIn, setIsUserLoggedIn] = useState(localStorage.getItem("user") && JSON.parse(localStorage.getItem("user")).accessToken ? true  : false);
    const [appointmentList, setAppointmentList] = useState([]);
    const [modalIsOpen, setIsOpen] = useState(false);
    const [selectedAppointment, setAppointment] = useState({});

    const openModal = (appointment) => {
        setAppointment(appointment);
        setIsOpen(true);
    }

    const closeModal = () => {
        setIsOpen(false);
        setAppointment({});
    }

    const getUserAppointments = async () => {
        const res = await getAppointments();
        if(res.status === 200){
            const data = await res.json();
            setAppointmentList(data);
        }
    }

    useEffect(() => {
        const intervalId = setInterval(() => {
            const user = localStorage.getItem("user");
            if(user && JSON.parse(localStorage.getItem("user")).accessToken){
                setIsUserLoggedIn(true);
            }else{
                setIsUserLoggedIn(false);
            }
        }, 1000);
        isUserLoggedIn && getUserAppointments();

        return () => clearInterval(intervalId);
        
    }, [isUserLoggedIn]);

    return (
        <div>
            {
                !isUserLoggedIn ?
                    <div className="mt-20">Login to see appointments.</div>
                :
                <div style={{textAlign: "start", marginTop: "20px"}}>
                    {
                        !!appointmentList.length &&
                        appointmentList.map((item) => {
                            return (
                                <Paper key={item.appointmentId} elevation={2} sx={{padding: "15px", margin: "10px"}}>
                                    <Typography component="div">
                                        <h4 className="doctor-name">Dr: {item.doctorName}</h4>
                                        <p className="doctor-speciality">Date: {item.appointmentDate}</p>
                                        <p className="doctor-rating">Symptoms: {item.symptoms}</p>
                                        <p className="doctor-rating">Prior medical history: {item.priorMedicalHistory}</p>
                                    </Typography>
                                    
                                    <Button onClick={() => openModal(item)}  variant="contained" color="primary" sx={{margin: "20px 0 5px 0"}}>RATE APPOINTMENT</Button>
                                </Paper>
                            )
                        })
                    }
                    
                </div>
                
            }

            <Modal
                isOpen={modalIsOpen}
                onRequestClose={closeModal}
                contentLabel="Rating Modal"
                className="modal"
                overlayClassName="modal-overlay"
            >
                <div className="modal-header">
                    <h2 className="modal-label">Rate an Appointment</h2>
                    <button onClick={closeModal}>X</button>   
                </div>
                <Card variant="outlined" sx={{borderRadius: 0, padding:"15px"}}>
                    <RateAppointment closeModal={closeModal} appointment={selectedAppointment}></RateAppointment>
                </Card>
            </Modal>
        </div>
    )
};

export default Appointment;