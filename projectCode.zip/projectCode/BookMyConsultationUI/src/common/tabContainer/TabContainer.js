import React from "react";
import Typography from "@material-ui/core/Typography";
import PropTypes from "prop-types";

const TabContainer = function (props) {
  const {value, index, children} = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
    >
      {value === index &&
        <Typography component="div" style={{ padding: 0, textAlign: "center" }}>
          {children}
        </Typography>
      }
    </div>
    
  );
};

TabContainer.propTypes = {
  children: PropTypes.node.isRequired,
};

export default TabContainer;
