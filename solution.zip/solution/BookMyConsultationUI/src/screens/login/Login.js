import React, { useState } from "react";
import FormControl from '@mui/material/FormControl';
import FormHelperText from '@mui/material/FormHelperText';
import Input from '@mui/material/Input';
import InputLabel from '@mui/material/InputLabel';
import Button from '@mui/material/Button';
import {authenticateUser} from "../../util/fetch";
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';

const Login = (props) => {
    
    const [formData, setFormData] = useState({
        "email": "",
        "pass": "",
    });

    const [errors, setErrors] = useState({
        "isEmailInvalid": false,
        "passReq": false,
        "emailReq": false,
    })

    const [open, setOpen] = React.useState(false);

    const handleClose = () => {
        setOpen(false);
    };
    
    const handleChange = (event, type) => {
        setFormData((prev) => {
            return {
                ...prev,
                [type]: event.target.value,
           }
        })

        if(type === "email"){
            setErrors((prev) => {
                return {
                    ...prev,
                    "isEmailInvalid": false,
                    "emailReq": false,
                }
            })
        } else if(type === "pass"){
            setErrors((prev) => {
                return {
                    ...prev,
                    "passReq": false,
                }
            })
        }

    };

    const validate = () => {
        let formErrors = {
            "isEmailInvalid": false,
            "passReq": false,
            "emailReq": false
        };
        let isFormValid = false;
        if(formData.email){
            formErrors["emailReq"] = false;
            formErrors["isEmailInvalid"] = !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test( formData.email);
            isFormValid = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test( formData.email);
        } else if(!formData.email) {
            formErrors["emailReq"] = true;
            formErrors["isEmailInvalid"] = false;
            isFormValid = false;
        }
        
        if(!formData.pass) {
            formErrors["passReq"] = true;
            isFormValid = false;
        } else if(formData.pass){
            formErrors["passReq"] = false;
            isFormValid = !(formErrors.emailReq || formErrors.isEmailInvalid);
        }
        setErrors(formErrors);
        return isFormValid;
    }

    const authenticate = async () => {
        if(validate()) {
            const payload = {
                emailId: formData.email,
                password: formData.pass
            }
            try {
                const res = await authenticateUser(payload);
                console.log(res);
                if(res.status === 200){
                    const data = await res.json();
                    localStorage.setItem("user", JSON.stringify(data));
                    props.setIsUserLoggedIn(true);
                    props.closeModal();
                } else {
                    setOpen(true);
                }
            } catch(e){
                console.log(e);
                
            }
        }
    };

    return (
        <form className="mt-20 mb-20">
            <FormControl variant="standard" sx={{width: "60%"}}>
                <InputLabel htmlFor="user-email">Email*</InputLabel>
                <Input
                    required
                    id="user-email"
                    value={formData.email}
                    type="email"
                    onChange={(e) => handleChange(e, 'email')}
                    aria-describedby="user-email-text"
                />
                <div className="mb-20">
                    {
                        errors.isEmailInvalid &&
                        <FormHelperText sx={{color: "red"}} >Enter vaild Email</FormHelperText>
                    }

                    {
                        errors.emailReq &&
                        <FormHelperText sx={{color: "red"}} >Email is required</FormHelperText>
                    }
                </div>
                
                
            </FormControl>

            <FormControl className="mt-20" variant="standard" sx={{width: "60%"}}>
                <InputLabel htmlFor="user-pass">Password*</InputLabel>
                <Input
                    required
                    id="user-pass"
                    type="password"
                    value={formData.pass}
                    onChange={(e) => handleChange(e, 'pass')}
                    aria-describedby="user-pass-text"
                />
                {
                        errors.passReq &&
                        <FormHelperText sx={{color: "red", marginBottom: "20px"}} >Password is required</FormHelperText>
                }
            </FormControl>

            <div className="mt-20">
                <Button variant="contained" onClick={authenticate}>LOGIN</Button>
            </div>

            <Dialog
                open={open}
                onClose={handleClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogTitle id="alert-dialog-title">
                    {"Error"}
                </DialogTitle>
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        Either email or password is invalid.
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleClose}>OK</Button>
                </DialogActions>
            </Dialog>    
            
        </form>
    );
}

export default Login;