import React, {useEffect, useState} from "react";
import Paper from '@mui/material/Paper';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import Typography from "@material-ui/core/Typography";
import Rating from '@mui/material/Rating';
import {getDoctors, getSpeciality, getDoctorBySpeciality} from '../../util/fetch';
import Button from '@mui/material/Button';
import Card from '@mui/material/Card';
import Modal from 'react-modal';
import BookAppointment from './BookAppointment';
import DoctorDetails from './DoctorDetails';
import './DoctorList.css';

Modal.setAppElement('#root');

const DoctorList = () => {
    const [doctorList, setDoctorList] = useState([]);
    const [specialityList, setSpecialityList] = useState([]);
    const [speciality, setspeciality] = useState('');
    const [modalIsOpen, setIsOpen] = useState(false);
    const [selectedDoctor, setSelectedDoctor] = useState({});
    const [isDetailModalActive, setDetailModalActive] = useState(false);

    const openModal = (doctor) => {
        setSelectedDoctor(doctor);
        setIsOpen(true);
    }

    const closeModal = () => {
        setIsOpen(false);
        setSelectedDoctor({});
    }

    const handleSpecialityChange = (event) => {
        setspeciality(event.target.value);
        getFilteredDoctors(event.target.value);
    };

    const getFilteredDoctors = async (speciality) => {
        const res = await getDoctorBySpeciality(speciality);
        if(res.status === 200){
            const data = await res.json();
            setDoctorList(data);
        }
    }

    useEffect( () => {
        async function fetchDoctorList() {
            const res = await getDoctors();
            if(res.status === 200){
                const data = await res.json();
                setDoctorList(data);
            }
        }

        async function fetchSpeciality() {
            const res = await getSpeciality();
            if(res.status === 200){
                const data = await res.json();
                console.log(data)
                setSpecialityList(data);
            }
        }

        fetchDoctorList();
        fetchSpeciality();
        
    }, []);

    return(
        <div className="doctor-list-sec">
            {
                !!specialityList.length && <FormControl variant="standard" sx={{ m: 1, minWidth: 200, marginLeft: "43%", marginBottom: "20px" }}>
                <InputLabel id="speciality-select--label">Select Speciality</InputLabel>
                <Select
                    labelId="speciality-select-label"
                    id="demo-simple-select-standard"
                    value={speciality}
                    onChange={handleSpecialityChange}
                    label="Select Speciality"
                >
                    <MenuItem value="">
                        <em>None</em>
                    </MenuItem>
                    {
                        specialityList.map((item) => {
                            return (
                                <MenuItem key={`id_${item}`} value={item}>{item}</MenuItem>
                            )
                        })
                    }
                </Select>
            </FormControl>
            }

            {
                !!doctorList.length && doctorList.map((item) => {
                    return (
                        <Paper key={item.id} elevation={2} sx={{width: "40%", margin: "auto", padding: "15px", marginBottom: "10px"}}>
                            <Typography component="div">
                                <h4 className="doctor-name">Doctor Name: {item.firstName} {item.lastName}</h4>
                                <p className="doctor-speciality">Speciality: {item.speciality}</p>
                                <p className="doctor-rating">Rating: <Rating name={`rating_${item.id}`} value={item.rating} readOnly /></p>
                            </Typography>
                            
                            <Button onClick={() => {openModal(item); setDetailModalActive(false)}} variant="contained" color="primary" sx={{width: "40%", margin: "10px"}}>BOOK APPOINTMENT</Button>
                            <Button onClick={() => {openModal(item); setDetailModalActive(true)}} variant="contained" color="success" sx={{width: "40%"}}>VIEW DETAILS</Button>
                        </Paper>
                    );
                })
            }

            <Modal
                isOpen={modalIsOpen}
                onRequestClose={closeModal}
                contentLabel="Appointment Modal"
                className="modal"
                overlayClassName="modal-overlay"
            >
                <div className="modal-header">
                    <h2 className="modal-label">{ isDetailModalActive ? "Doctor Details" : "Book an Appointment"}</h2>
                    <button onClick={closeModal}>X</button>   
                </div>
                <Card variant="outlined" sx={{borderRadius: 0, padding:"15px"}}>
                    {
                        isDetailModalActive ?
                        <DoctorDetails selectedDoctor={selectedDoctor} closeModal={closeModal}></DoctorDetails> :
                        <BookAppointment selectedDoctor={selectedDoctor} closeModal={closeModal}></BookAppointment>
                    }
                   
                </Card>
            </Modal>
            
        </div>
    )
};

export default DoctorList;