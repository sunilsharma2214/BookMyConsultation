import React from "react";
import { useState } from "react";
import FormControl from '@mui/material/FormControl';
import FormHelperText from '@mui/material/FormHelperText';
import Input from '@mui/material/Input';
import InputLabel from '@mui/material/InputLabel';
import Button from '@mui/material/Button';
import {register, authenticateUser} from "../../util/fetch";

const Register = (props) => {
    const [formData, setFormData] = useState({
        "fname": "",
        "lname": "",
        "email": "",
        "pass": "",
        "phone": "",
    });

    const [errors, setErrors] = useState({
        "isEmailInvalid": false,
        "isPhoneValid": false,
        "passReq": false,
        "emailReq": false,
        "fnameReq": false,
        "lnameReq": false,
        "phoneReq": false
    })
    
    const handleChange = (event, type) => {
        setFormData((prev) => {
            return {
                ...prev,
                [type]: event.target.value,
            }
        })
        if(type !== "email" && type !== "phone"){
            setErrors(prev => {
                return {
                    ...prev,
                    [`${type}Req`]: false
                }
            })
        }

        if(type === "email"){
            setErrors((prev) => {
                return {
                    ...prev,
                    "isEmailInvalid": false,
                    "emailReq": false
                }
            })
        }

        if(type === "phone"){
            setFormData((prev) => {
                return {
                    ...prev,
                    "isPhoneValid": false,
                    "phoneReq": false
                }
            })
        }
    };

    const validate = () => {
        let formErrors = {
            "isEmailInvalid": false,
            "isPhoneValid": false,
            "passReq": false,
            "emailReq": false,
            "fnameReq": false,
            "lnameReq": false,
            "phoneReq": false
        };
        let isFormValid = false;
        if(!formData.fname) {
            formErrors["fnameReq"] = true;
            isFormValid = false;
        } else if(formData.fname){
            formErrors["fnameReq"] = false;
        }

        if(!formData.lname) {
            formErrors["lnameReq"] = true;
        } else if(formData.fname){
            formErrors["lnameReq"] = false;
        }

        if(formData.email){
            formErrors["emailReq"] = false;
            formErrors["isEmailInvalid"] = !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test( formData.email);
        } else if(!formData.email) {
            formErrors["emailReq"] = true;
            formErrors["isEmailInvalid"] = false;
        }
        
        if(!formData.pass) {
            formErrors["passReq"] = true;
        } else if(formData.pass){
            formErrors["passReq"] = false;
        }

        if(formData.phone){
            formErrors["phoneReq"] = false;
            formErrors["isPhoneValid"] = !(/^[0-9]{10}$/g.test( formData.phone));
        } else if(!formData.phone) {
            formErrors["phoneReq"] = true;
            formErrors["isPhoneValid"] = false;
        }

        isFormValid = !(formErrors.emailReq || formErrors.isEmailInvalid || formErrors.fnameReq || formErrors.lnameReq || formErrors.passReq || formErrors.phoneReq || formErrors.isPhoneValid);
        setErrors(formErrors);
        return isFormValid;
    }

    const registerUser = async () => {
        console.log(formData);
        if(validate()){
            const payload = {
                "firstName": formData.fname,
                "lastName": formData.lname,
                "mobile": formData.phone,
                "password": formData.pass,
                "emailId": formData.email
            }
            const res = await register(payload);
            if(res.status === 200){
                const loginPayload = {
                    emailId: formData.email,
                    password: formData.pass
                }
                try {
                    const loginRes = await authenticateUser(loginPayload);
                    console.log(loginRes);
                    if(loginRes.status === 200){
                        const data = await loginRes.json();
                        localStorage.setItem("user", JSON.stringify(data));
                        props.setIsUserLoggedIn(true);
                        props.closeModal();
                    }
                } catch(e){
                    console.log(e);
                }
            }
        }
        
    };

    return (
        <form className="mt-20 mb-20">
            <FormControl variant="standard" sx={{width: "60%", marginBottom: "20px"}}>
                <InputLabel htmlFor="user-pass">First Name*</InputLabel>
                <Input
                    required
                    id="user-fname"
                    type="text"
                    value={formData.fname}
                    onChange={(e) => handleChange(e, 'fname')}
                    aria-describedby="user-fname-text"
                />
                {
                        errors.fnameReq &&
                        <FormHelperText sx={{color: "red"}} >First name is required</FormHelperText>
                }
            </FormControl>

            <FormControl  variant="standard" sx={{width: "60%", marginBottom: "20px"}}>
                <InputLabel htmlFor="user-lname">Last Name*</InputLabel>
                <Input
                    required
                    id="user-lname"
                    type="text"
                    value={formData.lname}
                    onChange={(e) => handleChange(e, 'lname')}
                    aria-describedby="user-lname-text"
                />
                {
                        errors.lnameReq &&
                        <FormHelperText sx={{color: "red"}} >Last name is required</FormHelperText>
                }
            </FormControl>

            <FormControl  variant="standard" sx={{width: "60%"}}>
                <InputLabel htmlFor="user-email">Email Id*</InputLabel>
                <Input
                    required
                    id="user-email"
                    value={formData.email}
                    type="email"
                    onChange={(e) => handleChange(e, 'email')}
                    aria-describedby="user-email-text"
                />
                <div className="mb-20">
                    {
                        errors.isEmailInvalid &&
                        <FormHelperText sx={{color: "red"}} >Enter vaild Email</FormHelperText>
                    }

                    {
                        errors.emailReq &&
                        <FormHelperText sx={{color: "red"}} >Email Id is required</FormHelperText>
                    }
                </div>
                
                
            </FormControl>

            <FormControl  variant="standard" sx={{width: "60%", marginBottom: "20px"}}>
                <InputLabel htmlFor="user-pass">Password*</InputLabel>
                <Input
                    required
                    id="user-pass"
                    type="password"
                    value={formData.pass}
                    onChange={(e) => handleChange(e, 'pass')}
                    aria-describedby="user-pass-text"
                />
                {
                        errors.passReq &&
                        <FormHelperText sx={{color: "red"}} >Password is required</FormHelperText>
                }
            </FormControl>

            <FormControl variant="standard" sx={{width: "60%"}}>
                <InputLabel htmlFor="user-phone">Mobile No*</InputLabel>
                <Input
                    required
                    id="user-phone"
                    type="text"
                    value={formData.phone}
                    onChange={(e) => handleChange(e, 'phone')}
                    aria-describedby="user-phone-text"
                />
                <div className="mb-20">
                    {
                        errors.isPhoneValid &&
                        <FormHelperText sx={{color: "red"}} >Enter vaild Phone</FormHelperText>
                    }

                    {
                        errors.phoneReq &&
                        <FormHelperText sx={{color: "red"}} >Phone is required</FormHelperText>
                    }
                </div>
            </FormControl>

            <div className="mt-20">
                <Button variant="contained" onClick={registerUser}>REGISTER</Button>
            </div>
            
        </form>
    );
}

export default Register;