import React from "react";
import { useState } from "react";
import Button from '@mui/material/Button';
import Card from '@mui/material/Card';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Modal from 'react-modal';
import TabContainer from '../tabContainer/TabContainer';
import Login from '../../screens/login/Login';
import Register from '../../screens/register/Register';
import {logout} from '../../util/fetch';
import "./Header.css"

Modal.setAppElement('#root');

const Header = () => {
    const [modalIsOpen, setIsOpen] = useState(false);
    const [tabValue, setTabValue] = React.useState(0);
    const [isUserLoggedIn, setIsUserLoggedIn] = useState(localStorage.getItem("user") && JSON.parse(localStorage.getItem("user")).accessToken ? true : false);
    
    const onTabChange = (event, newValue) => {
        setTabValue(newValue);
    };

    const a11yProps = (index) => {
        return {
          id: `simple-tab-${index}`,
          'aria-controls': `simple-tabpanel-${index}`,
        };
    }

    const openModal = () => {
        setIsOpen(true);
    }

    const closeModal = () => {
        setIsOpen(false);
    }

    const logoutUser = async () => {
        const res = await logout();
        console.log(res);
        if(res.status === 200){
            setIsUserLoggedIn(false);
        }
    }

    return (
        <header className="app-header">
            <div className="app-logo">
                <img src={require('../../assets/logo.jpeg')} alt="logo"></img>
                <span className="">Doctor Finder</span>
            </div>
            <div className="header-menu">
                {
                    !isUserLoggedIn ?
                    <Button variant="contained" color="primary" onClick={openModal}>Login</Button>
                    :
                    <Button variant="contained" color="secondary" onClick={logoutUser}>Logout</Button>
                }
                
            </div>
            <Modal
                isOpen={modalIsOpen}
                onRequestClose={closeModal}
                contentLabel="Authentication Modal"
                className="modal"
                overlayClassName="modal-overlay"
            >
                
                <div className="modal-header">
                    <h2 className="modal-label">Authentication</h2>
                    <button onClick={closeModal}>X</button>   
                </div>
                <Card variant="outlined" sx={{borderRadius: 0}}>
                    <Tabs
                        value={tabValue}
                        onChange={onTabChange}
                        aria-label="Auth tabs"
                        sx={{padding: "0 10px"}}
                    >
                        <Tab label="LOGIN" {...a11yProps(0)} sx={{flexBasis: "50%"}} />
                        <Tab label="REGISTER" {...a11yProps(1)} sx={{flexBasis: "50%"}} />
                    </Tabs>
                    <TabContainer value={tabValue} index={0}>
                        <Login closeModal={closeModal} setIsUserLoggedIn={setIsUserLoggedIn}></Login>
                    </TabContainer>
                    <TabContainer value={tabValue} index={1}>
                        <Register closeModal={closeModal} setIsUserLoggedIn={setIsUserLoggedIn}></Register>
                    </TabContainer>
                </Card>
            </Modal>
        </header>
    );
};

export default Header;