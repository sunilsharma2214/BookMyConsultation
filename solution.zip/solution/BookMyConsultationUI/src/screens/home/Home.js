import React from "react";
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import TabContainer from '../../common/tabContainer/TabContainer';
import DoctorList from '../doctorList/DoctorList';
import Appointment from '../appointment/Appointment';

const Home = () => {
    const [tabValue, setTabValue] = React.useState(0);

    const onTabChange = (event, newValue) => {
        setTabValue(newValue);
    };

    const a11yProps = (index) => {
        return {
          id: `simple-tab-${index}`,
          'aria-controls': `simple-tabpanel-${index}`,
        };
    }
    return (
        <>
            <Tabs
                value={tabValue}
                onChange={onTabChange}
                aria-label="Home tabs"
                sx={{padding: "0 10px"}}
            >
                <Tab label="DOCTORS" {...a11yProps(0)} sx={{flexBasis: "50%", maxWidth: "inherit"}} />
                <Tab label="APPOINTMENT" {...a11yProps(1)} sx={{flexBasis: "50%", maxWidth: "inherit"}} />
            </Tabs>
            <TabContainer value={tabValue} index={0}>
                <DoctorList></DoctorList>
            </TabContainer>
            <TabContainer value={tabValue} index={1}>
                <Appointment></Appointment>
            </TabContainer>
        </>
    )
};

export default Home;