import React, {useState, useEffect} from "react";
import FormControl from '@mui/material/FormControl';
import FormHelperText from '@mui/material/FormHelperText';
import TextField from '@mui/material/TextField';
import Input from '@mui/material/Input';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import AdapterDateFns from '@mui/lab/AdapterDateFns';
import LocalizationProvider from '@mui/lab/LocalizationProvider';
import DatePicker from '@mui/lab/DatePicker';
import {getTimeSlotList, bookUserAppointment, getAppointments} from '../../util/fetch';

const BookAppointment = (props) => {
    const [isUserLoggedIn, setIsUserLoggedIn] = useState(localStorage.getItem("user") && JSON.parse(localStorage.getItem("user")).accessToken ? true  : false);
    const [selectedTimeSlot, setTimeSlot] = useState('');
    const [timeSlotList, setTimeSlotList] = useState([]);
    const [selectedDate, setSelectedDate] = useState('');
    const [timeSlotErr, setTimeSlotErr] = useState(false);
    const [symptoms, setSymptoms] = useState('');
    const [priorMedicalHistory, setPriorMedicalHistory] = useState('');
    const [open, setOpen] = React.useState(false);

    const handleClose = () => {
        setOpen(false);
    };

    const handleTimeSlotChange = (event) => {
        setTimeSlot(event.target.value);
    };

    const dateInString = (date) => {
        const dd = String(date.getDate()).padStart(2, '0');
        const mm = String(date.getMonth() + 1).padStart(2, '0'); //January is 0!
        const yyyy = date.getFullYear();

        date = mm + '/' + dd + '/' + yyyy;
        return date;
    }

    const bookAppointment = async () => {
        if(!selectedTimeSlot){
            setTimeSlotErr(true);
            return;
        }
        setTimeSlotErr(false);
        const userDetail = JSON.parse(localStorage.getItem("user"));

        
        let date = selectedDate.split('/');
        date = date[2] + "-" + date[0] + "-" + date[1];

        const appointments = await getAppointments();
        if(appointments.status === 200){
            const data = await appointments.json();
            const selectedDoctorApp = data.filter((item) => {
                return item.doctorId === props.selectedDoctor.id && item.appointmentDate === date && item.timeSlot === selectedTimeSlot
            })
            
            if(selectedDoctorApp.length){
                setOpen(true);
            } else {
                //book appointment
                const payload = {
                    "doctorId": props.selectedDoctor.id,
                    "doctorName": props.selectedDoctor.firstName + " " + props.selectedDoctor.lastName,
                    "userId": userDetail.id,
                    "userName": userDetail.firstName,
                    "userEmailId": userDetail.emailAddress,
                    "timeSlot": selectedTimeSlot,
                    "appointmentDate": date,
                    "createdDate": "",
                    "symptoms": symptoms,
                    "priorMedicalHistory": priorMedicalHistory
                };
                const res = await bookUserAppointment(payload)
                if(res.status === 201){
                    props.closeModal();
                }
            }
        } else {
            console.log("something went wrong");
        }
    }

    useEffect( () => {
        setSelectedDate(dateInString(new Date()));
    }, []);

    useEffect( () => {
        async function fetchTimeSlotList() {
            let date = selectedDate.split('/');
            date = date[2] + "-" + date[0] + "-" + date[1];
            const payload = {
                id: props.selectedDoctor.id,
                date: date
            };
            
            const res = await getTimeSlotList(payload);
            if(res.status === 200){
                const data = await res.json();
                setTimeSlotList(data.timeSlot);
            }
        }
        
        selectedDate && fetchTimeSlotList();
        
    }, [selectedDate]);

    useEffect(() => {
        const intervalId = setInterval(() => {
            const user = localStorage.getItem("user");
            if(user && JSON.parse(localStorage.getItem("user")).accessToken){
                setIsUserLoggedIn(true);
            }else{
                setIsUserLoggedIn(false);
            }
        }, 1000);
        
        return () => clearInterval(intervalId);
        
    }, [isUserLoggedIn]);

    return (
        <>
            {
                !isUserLoggedIn ?
                "login to book the appointment" :
                <form className="">
                    <FormControl variant="standard" sx={{width: "60%", marginBottom: "20px"}}>
                        <InputLabel htmlFor="doctor-name">Doctor Name*</InputLabel>
                        <Input
                            readOnly
                            id="doctor-name"
                            type="text"
                            value={`${props.selectedDoctor.firstName} ${props.selectedDoctor.lastName}` }
                            aria-describedby="doctor-name-text"
                        />
                    </FormControl>

                    <LocalizationProvider dateAdapter={AdapterDateFns}>
                        <DatePicker
                            label="Date picker inline"
                            value={selectedDate}
                            onChange={(newValue) => {
                                setSelectedDate(dateInString(newValue));
                            }}
                            renderInput={(params) => <TextField {...params} />}
                        />
                    </LocalizationProvider>

                    <FormControl variant="standard" sx={{ m: 1, minWidth: 200, margin: "20px 0"}}>
                        <InputLabel id="time-slot-select--label">Timeslot</InputLabel>
                        <Select
                            labelId="time-slot-select-label"
                            value={selectedTimeSlot}
                            onChange={handleTimeSlotChange}
                            label="Select Timeslot"
                        >
                            <MenuItem value="">
                                <em>None</em>
                            </MenuItem>
                            {
                                timeSlotList.length && timeSlotList.map((item, index) => {
                                    return (
                                        <MenuItem key={`id_${index}`} value={item}>{item}</MenuItem>
                                    )
                                })
                            }
                        </Select>
                        {
                            timeSlotErr &&
                            <FormHelperText sx={{color: "red"}} >Select a time slot</FormHelperText>
                        }
                    </FormControl>
                    
                    <div>
                        <TextField
                            value={priorMedicalHistory}
                            label="Medical History"
                            variant="standard"
                            sx={{marginBottom: "20px"}}
                            onChange={(e) => {
                                setPriorMedicalHistory(e.target.value);
                            }}
                        />
                    </div>
                    
                    <div>
                        <TextField
                            label="Symptoms"
                            helperText="ex. Cold, Swelling etc"
                            variant="standard"
                            value={symptoms}
                            sx={{marginBottom: "20px"}}
                            onChange={(e) => {
                                setSymptoms(e.target.value);
                            }}
                        />
                    </div>

                    <Button variant="contained" onClick={bookAppointment}>BOOK APPOINTMENT</Button>
                </form>
            }

            <Dialog
                open={open}
                onClose={handleClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogTitle id="alert-dialog-title">
                    {"Slot Not Available"}
                </DialogTitle>
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        Either the slot is already booked or not available.
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleClose}>OK</Button>
                </DialogActions>
            </Dialog>           
        </>
    );
}

export default BookAppointment;